Para comprobar si un numero es entero en javascript a partir de html con el input="text" 
y forzar asi al usuario que a�ada un numero entero para el campo id y no a�ada texto, 
he sacado la informacion a partir de la siguiente pagina web,

http://programandoointentandolo.com/2013/04/como-saber-si-un-numero-es-decimal-o-entero-en-javascript.html